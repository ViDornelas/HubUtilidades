package com.example.hubutilidades;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class FelicidadeFormActivity extends AppCompatActivity {

    private CheckBox cbEstudando, cbTrabalhando, cbFolga;
    private RadioGroup rgSono, rgEstresse;
    private Button btnCalcular, btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_felicidade_form);

        cbEstudando   = findViewById(R.id.cbEstudando);
        cbTrabalhando = findViewById(R.id.cbTrabalhando);
        cbFolga       = findViewById(R.id.cbFolga);
        rgSono        = findViewById(R.id.rgSono);
        rgEstresse    = findViewById(R.id.rgEstresse);
        btnCalcular   = findViewById(R.id.btnCalcularFelicidade);
        btnVoltar     = findViewById(R.id.btnVoltarFelicidadeForm);

        btnCalcular.setOnClickListener(v -> calcular());
        btnVoltar.setOnClickListener(v   -> voltarMenu());
    }

    private void calcular() {
        // Validação sono
        if (rgSono.getCheckedRadioButtonId() == -1) {
            Toast.makeText(this, "Selecione uma opção de sono!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validação estresse
        if (rgEstresse.getCheckedRadioButtonId() == -1) {
            Toast.makeText(this, "Selecione seu nível de estresse!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Peso do Sono
        int pesoSono = 1;
        int sonoId = rgSono.getCheckedRadioButtonId();
        if      (sonoId == R.id.rbSono1) pesoSono = 1;  // 0-3h
        else if (sonoId == R.id.rbSono2) pesoSono = 3;  // 4-8h
        else if (sonoId == R.id.rbSono3) pesoSono = 2;  // 9-12h

        // Peso do Estresse
        int pesoEstresse = 1;
        int estresseId = rgEstresse.getCheckedRadioButtonId();
        if      (estresseId == R.id.rbEstresse1) pesoEstresse = 3;  // 0-3
        else if (estresseId == R.id.rbEstresse2) pesoEstresse = 2;  // 4-7
        else if (estresseId == R.id.rbEstresse3) pesoEstresse = 1;  // 8-10

        // Cálculo: [(S + E) / 6] * 10
        double felicidade = ((double)(pesoSono + pesoEstresse) / 6.0) * 10.0;

        // Atividades selecionadas
        StringBuilder atividades = new StringBuilder();
        if (cbEstudando.isChecked())   appendAtividade(atividades, "Estudando");
        if (cbTrabalhando.isChecked()) appendAtividade(atividades, "Trabalhando");
        if (cbFolga.isChecked())       appendAtividade(atividades, "Folga");
        if (atividades.length() == 0)  atividades.append("Nenhuma informada");

        // Labels para exibição
        String labelSono;
        if      (sonoId == R.id.rbSono1) labelSono = "0 a 3 horas (peso 1)";
        else if (sonoId == R.id.rbSono2) labelSono = "4 a 8 horas (peso 3)";
        else                             labelSono = "9 a 12 horas (peso 2)";

        String labelEstresse;
        if      (estresseId == R.id.rbEstresse1) labelEstresse = "0 a 3 (peso 3)";
        else if (estresseId == R.id.rbEstresse2) labelEstresse = "4 a 7 (peso 2)";
        else                                     labelEstresse = "8 a 10 (peso 1)";

        // Navegar para resultado
        Intent intent = new Intent(this, FelicidadeResultActivity.class);
        intent.putExtra("felicidade",    felicidade);
        intent.putExtra("labelSono",     labelSono);
        intent.putExtra("labelEstresse", labelEstresse);
        intent.putExtra("atividades",    atividades.toString());
        startActivity(intent);
    }

    private void appendAtividade(StringBuilder sb, String item) {
        if (sb.length() > 0) sb.append(", ");
        sb.append(item);
    }

    private void voltarMenu() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        voltarMenu();
    }
}

package com.example.hubutilidades;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class JokenpoActivity extends AppCompatActivity {

    private static final String[] OPCOES     = {"Pedra", "Papel", "Tesoura"};
    private static final String[] EMOJIS     = {"✊", "✋", "✌️"};

    private TextView tvPlacarVoce, tvPlacarPC, tvResultado, tvEscolhas;
    private Button btnPedra, btnPapel, btnTesoura, btnReiniciar, btnVoltar;

    private int placarVoce = 0;
    private int placarPC   = 0;
    private boolean jogoEncerrado = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jokenpo);

        tvPlacarVoce = findViewById(R.id.tvPlacarVoce);
        tvPlacarPC   = findViewById(R.id.tvPlacarPC);
        tvResultado  = findViewById(R.id.tvResultadoJokenpo);
        tvEscolhas   = findViewById(R.id.tvEscolhasJokenpo);

        btnPedra    = findViewById(R.id.btnPedra);
        btnPapel    = findViewById(R.id.btnPapel);
        btnTesoura  = findViewById(R.id.btnTesoura);
        btnReiniciar = findViewById(R.id.btnReiniciarJokenpo);
        btnVoltar   = findViewById(R.id.btnVoltarJokenpo);

        btnPedra.setOnClickListener(v   -> jogar(0));
        btnPapel.setOnClickListener(v   -> jogar(1));
        btnTesoura.setOnClickListener(v -> jogar(2));

        btnReiniciar.setOnClickListener(v -> reiniciarJogo());

        btnVoltar.setOnClickListener(v -> voltarMenu());
    }

    private void jogar(int escolhaVoce) {
        if (jogoEncerrado) {
            Toast.makeText(this, "Jogo encerrado! Clique em Reiniciar.", Toast.LENGTH_SHORT).show();
            return;
        }

        int escolhaPC = new Random().nextInt(3);

        String descricaoVoce = EMOJIS[escolhaVoce] + " " + OPCOES[escolhaVoce];
        String descricaoPC   = EMOJIS[escolhaPC]   + " " + OPCOES[escolhaPC];

        tvEscolhas.setText("Você: " + descricaoVoce + "  |  PC: " + descricaoPC);

        int resultado = determinarVencedor(escolhaVoce, escolhaPC);

        if (resultado == 1) {
            placarVoce++;
            tvResultado.setText("🎉 Você venceu esta rodada!");
        } else if (resultado == -1) {
            placarPC++;
            tvResultado.setText("😢 O PC venceu esta rodada!");
        } else {
            tvResultado.setText("🤝 Empate!");
        }

        tvPlacarVoce.setText(String.valueOf(placarVoce));
        tvPlacarPC.setText(String.valueOf(placarPC));

        // Verifica melhor de 3
        if (placarVoce == 2) {
            tvResultado.setText("🏆 PARABÉNS! Você ganhou o jogo!");
            jogoEncerrado = true;
        } else if (placarPC == 2) {
            tvResultado.setText("💻 O PC ganhou o jogo! Tente novamente.");
            jogoEncerrado = true;
        }
    }

    /**
     * Retorna: 1 = jogador vence, -1 = PC vence, 0 = empate
     * Pedra(0) > Tesoura(2), Papel(1) > Pedra(0), Tesoura(2) > Papel(1)
     */
    private int determinarVencedor(int voce, int pc) {
        if (voce == pc) return 0;
        if ((voce == 0 && pc == 2) ||
            (voce == 1 && pc == 0) ||
            (voce == 2 && pc == 1)) {
            return 1;
        }
        return -1;
    }

    private void reiniciarJogo() {
        placarVoce    = 0;
        placarPC      = 0;
        jogoEncerrado = false;
        tvPlacarVoce.setText("0");
        tvPlacarPC.setText("0");
        tvResultado.setText("Faça sua escolha!");
        tvEscolhas.setText("");
    }

    private void voltarMenu() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        voltarMenu();
    }
}

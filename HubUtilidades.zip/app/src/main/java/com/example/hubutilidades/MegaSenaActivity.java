package com.example.hubutilidades;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class MegaSenaActivity extends AppCompatActivity {

    private TextView tvNumeros;
    private RadioGroup rgQuantidade;
    private Button btnGerar, btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mega_sena);

        tvNumeros    = findViewById(R.id.tvNumeros);
        rgQuantidade = findViewById(R.id.rgQuantidade);
        btnGerar     = findViewById(R.id.btnGerar);
        btnVoltar    = findViewById(R.id.btnVoltarMega);

        btnGerar.setOnClickListener(v -> gerarNumeros());

        btnVoltar.setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        });
    }

    private void gerarNumeros() {
        int quantidade = 6;
        int selected = rgQuantidade.getCheckedRadioButtonId();
        if (selected == R.id.rb7) quantidade = 7;
        else if (selected == R.id.rb8) quantidade = 8;

        List<Integer> numeros = new ArrayList<>();
        Random random = new Random();

        while (numeros.size() < quantidade) {
            int num = random.nextInt(60) + 1;
            if (!numeros.contains(num)) {
                numeros.add(num);
            }
        }

        Collections.sort(numeros);

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < numeros.size(); i++) {
            sb.append(String.format("%02d", numeros.get(i)));
            if (i < numeros.size() - 1) sb.append("  ");
        }

        tvNumeros.setText(sb.toString());
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }
}

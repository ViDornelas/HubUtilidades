package com.example.hubutilidades;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class FelicidadeResultActivity extends AppCompatActivity {

    private TextView tvEmoji, tvPontuacao, tvClassificacao, tvDescricao;
    private TextView tvDetalhesSono, tvDetalhesEstresse, tvDetalhesAtividade, tvDetalhesFormula;
    private Button btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_felicidade_result);

        tvEmoji            = findViewById(R.id.tvEmojiFelicidade);
        tvPontuacao        = findViewById(R.id.tvPontuacaoFelicidade);
        tvClassificacao    = findViewById(R.id.tvClassificacaoFelicidade);
        tvDescricao        = findViewById(R.id.tvDescricaoFelicidade);
        tvDetalhesSono     = findViewById(R.id.tvDetalhesSono);
        tvDetalhesEstresse = findViewById(R.id.tvDetalhesEstresse);
        tvDetalhesAtividade= findViewById(R.id.tvDetalhesAtividade);
        tvDetalhesFormula  = findViewById(R.id.tvDetalhesFormula);
        btnVoltar          = findViewById(R.id.btnVoltarFelicidadeResult);

        // Recebe dados
        double felicidade    = getIntent().getDoubleExtra("felicidade", 0);
        String labelSono     = getIntent().getStringExtra("labelSono");
        String labelEstresse = getIntent().getStringExtra("labelEstresse");
        String atividades    = getIntent().getStringExtra("atividades");

        // Exibe pontuação
        tvPontuacao.setText(String.format("%.1f", felicidade));

        // Classifica
        String emoji, classificacao, descricao;

        if (felicidade <= 2.0) {
            emoji         = "😢";
            classificacao = "Muito Baixa";
            descricao     = "Alerta crítico — cuide-se!";
        } else if (felicidade <= 4.0) {
            emoji         = "😟";
            classificacao = "Baixa";
            descricao     = "Equilíbrio precário — atenção necessária.";
        } else if (felicidade <= 6.0) {
            emoji         = "😐";
            classificacao = "Moderada";
            descricao     = "Estado neutro — há espaço para melhorar.";
        } else if (felicidade <= 8.0) {
            emoji         = "😊";
            classificacao = "Alta";
            descricao     = "Bom equilíbrio — continue assim!";
        } else {
            emoji         = "😄";
            classificacao = "Plena";
            descricao     = "Estado ideal — você está ótimo!";
        }

        tvEmoji.setText(emoji);
        tvClassificacao.setText(classificacao);
        tvDescricao.setText(descricao);

        // Detalhes
        tvDetalhesSono.setText("🌙 Sono: " + labelSono);
        tvDetalhesEstresse.setText("⚡ Estresse: " + labelEstresse);
        tvDetalhesAtividade.setText("📋 Atividade: " + atividades);
        tvDetalhesFormula.setText("Fórmula: [(S + E) / 6] × 10 = " + String.format("%.1f", felicidade));

        btnVoltar.setOnClickListener(v -> voltarMenu());
    }

    private void voltarMenu() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        voltarMenu();
    }
}

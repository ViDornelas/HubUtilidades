package com.example.hubutilidades;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class IMCActivity extends AppCompatActivity {

    private EditText etPeso, etAltura;
    private TextView tvIMCValor, tvIMCClassificacao;
    private Button btnCalcular, btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_imc);

        etPeso              = findViewById(R.id.etPeso);
        etAltura            = findViewById(R.id.etAltura);
        tvIMCValor          = findViewById(R.id.tvIMCValor);
        tvIMCClassificacao  = findViewById(R.id.tvIMCClassificacao);
        btnCalcular         = findViewById(R.id.btnCalcularIMC);
        btnVoltar           = findViewById(R.id.btnVoltarIMC);

        btnCalcular.setOnClickListener(v -> calcularIMC());

        btnVoltar.setOnClickListener(v -> voltarMenu());
    }

    private void calcularIMC() {
        String pesoStr   = etPeso.getText().toString().trim();
        String alturaStr = etAltura.getText().toString().trim();

        if (pesoStr.isEmpty() || alturaStr.isEmpty()) {
            Toast.makeText(this, "Por favor, preencha todos os campos!", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double peso   = Double.parseDouble(pesoStr);
            double altura = Double.parseDouble(alturaStr);

            if (peso <= 0 || altura <= 0) {
                Toast.makeText(this, "Valores devem ser maiores que zero!", Toast.LENGTH_SHORT).show();
                return;
            }

            if (altura > 3.0) {
                Toast.makeText(this, "Altura inválida! Use metros (ex: 1.75)", Toast.LENGTH_SHORT).show();
                return;
            }

            double imc = peso / (altura * altura);
            String classificacao = classificarIMC(imc);

            tvIMCValor.setText(String.format("%.1f", imc));
            tvIMCClassificacao.setText(classificacao);

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Valores inválidos! Use números (ex: 70.5)", Toast.LENGTH_SHORT).show();
        }
    }

    private String classificarIMC(double imc) {
        if (imc < 18.5)       return "⚠️ Abaixo do peso";
        else if (imc < 25.0)  return "✅ Peso normal";
        else if (imc < 30.0)  return "⚠️ Sobrepeso";
        else if (imc < 35.0)  return "🔴 Obesidade Grau I";
        else if (imc < 40.0)  return "🔴 Obesidade Grau II";
        else                  return "🔴 Obesidade Grau III";
    }

    private void voltarMenu() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        voltarMenu();
    }
}

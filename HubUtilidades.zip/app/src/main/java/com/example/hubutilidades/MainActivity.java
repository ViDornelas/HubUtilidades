package com.example.hubutilidades;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button btnMegaSena, btnIMC, btnJokenpo, btnFelicidade;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnMegaSena   = findViewById(R.id.btnMegaSena);
        btnIMC        = findViewById(R.id.btnIMC);
        btnJokenpo    = findViewById(R.id.btnJokenpo);
        btnFelicidade = findViewById(R.id.btnFelicidade);

        btnMegaSena.setOnClickListener(v ->
                startActivity(new Intent(this, MegaSenaActivity.class)));

        btnIMC.setOnClickListener(v ->
                startActivity(new Intent(this, IMCActivity.class)));

        btnJokenpo.setOnClickListener(v ->
                startActivity(new Intent(this, JokenpoActivity.class)));

        btnFelicidade.setOnClickListener(v ->
                startActivity(new Intent(this, FelicidadeFormActivity.class)));
    }
}
